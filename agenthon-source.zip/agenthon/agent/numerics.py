"""Small, cutoff-local statistical tools; no fitted external artifacts or task answers."""
import math
import statistics as st


def quantile(values, q):
    xs = sorted(float(v) for v in values)
    if not xs:
        raise ValueError('Empty sample')
    pos = (len(xs)-1)*q
    lo = int(pos)
    return xs[lo] + (xs[min(lo+1, len(xs)-1)]-xs[lo])*(pos-lo)


def _predict(xs, method, horizon):
    if method == 'last':
        return xs[-1]
    if method == 'median':
        return st.median(xs[-6:])
    if method == 'mean':
        return st.mean(xs[-6:])
    if method == 'ewma':
        result = xs[0]
        for value in xs[1:]:
            result = 0.35*value + 0.65*result
        return result
    if method == 'trend':
        y = xs[-6:]
        n = len(y)
        xm, ym = (n-1)/2, st.mean(y)
        den = sum((i-xm)**2 for i in range(n))
        slope = sum((i-xm)*(v-ym) for i,v in enumerate(y))/den if den else 0
        # Damping limits extrapolation in a small sample; selected by past-only CV.
        return ym + slope*((n-1)/2+0.5*horizon)
    raise ValueError('Unknown method')


def series_forecast(values, horizon=1, level=0.9, bounds=None):
    """Chronological CV on historical observations; intervals are small-sample estimates.

    Caller must supply a consistently defined target series available at task cutoff.
    No held-out task outcome enters selection or interval estimation.
    """
    xs = [float(v) for v in values]
    if len(xs) < 6 or not all(math.isfinite(v) for v in xs):
        raise ValueError('Need at least six finite chronological historical observations')
    if type(horizon) is not int or not 1 <= horizon <= min(24, len(xs)//2):
        raise ValueError('Invalid horizon')
    methods = ['last', 'median', 'mean', 'ewma', 'trend']
    residuals = {name:[] for name in methods}
    for end in range(4, len(xs)-horizon+1):
        truth = xs[end+horizon-1]
        for name in methods:
            residuals[name].append(truth-_predict(xs[:end],name,horizon))
    if not residuals['last']:
        raise ValueError('Insufficient backtest origins')
    losses = {name:st.mean(abs(v) for v in res) for name,res in residuals.items()}
    # Blend two independently defined baselines, avoiding zero-loss weight singularities.
    chosen = sorted(methods, key=lambda name:(losses[name],name))[:2]
    forecast = st.mean(_predict(xs,name,horizon) for name in chosen)
    errors = [st.mean(residuals[name][i] for name in chosen) for i in range(len(residuals['last']))]
    # Absolute residuals prevent selecting a narrow but badly shifted interval.
    rank = min(len(errors), math.ceil((len(errors)+1)*level))
    half = sorted(abs(v) for v in errors)[rank-1]
    half = max(half, abs(forecast)*0.01, (max(xs)-min(xs))*0.02, 1e-6)
    lo, hi = forecast-half, forecast+half
    if bounds is not None:
        forecast = min(bounds[1],max(bounds[0],forecast))
        lo,hi = max(bounds[0],lo),min(bounds[1],hi)
        lo,hi = min(lo,forecast),max(hi,forecast)
    return {'point_forecast':forecast,'interval':{'lo':lo,'hi':hi},
            'methods':chosen,'backtest_mae':st.mean(abs(v) for v in errors),
            'origins':len(errors),'history_n':len(xs),'horizon':horizon,
            'interval_status':'historical-residual estimate; future coverage unverified'}

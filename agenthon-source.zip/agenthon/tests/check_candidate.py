"""Offline interface checks; intentionally reports no accuracy or rank."""
import importlib.util
import json
import math
import sys
import tempfile
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "source/Agenthon2026-public-2.5.1/common/qfbench2_common/schemas/analysis.schema.json"
validator = Draft202012Validator(json.loads(SCHEMA.read_text(encoding="utf-8")))
spec = importlib.util.spec_from_file_location("candidate", ROOT / "agent/analyze.py")
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)


def check_answer(answer, task, passages, allowed):
    validator.validate(answer)
    assert [p["entity_id"] for p in answer["entity_predictions"]] == [e["entity_id"] for e in task["entities"]]
    by_doc = {}
    for p in passages:
        by_doc.setdefault(p.doc_id, []).append(p)
    for row in answer["entity_predictions"]:
        assert agent.finite(row["point_forecast"])
        band = row["interval"]
        assert band["level"] == task.get("interval_level", 0.9)
        assert band["lo"] <= row["point_forecast"] <= band["hi"]
        if task["target"]["type"] == "classification":
            assert row["label"] in task["target"]["labels"]
        assert row["claims"]
        for claim in row["claims"]:
            entry = allowed[claim["doc_id"]]
            assert entry.get("shared") or row["entity_id"] in entry.get("entity_ids", [])
            assert any(p.span_start <= claim["span_start"] < claim["span_end"] <= p.span_end
                       and p.text[claim["span_start"]-p.span_start:claim["span_end"]-p.span_start] == claim["claim"]
                       for p in by_doc[claim["doc_id"]])


class ValidMock:
    def complete(self, prompt):
        payload = json.loads(prompt)
        predictions = []
        for context in payload["predict_these"]:
            eid = context["entity"]["entity_id"]
            row = {"entity_id": eid, "point_forecast": 1.0, "interval": {"lo": 0.5, "hi": 1.5},
                   "evidence_ids": [context["evidence"][0]["passage_id"]]}
            labels = payload["task"]["target"].get("labels", [])
            if labels:
                row["label"] = labels[0]
            predictions.append(row)
        return {"predictions": predictions}


class BrokenMock:
    def complete(self, prompt):
        raise OSError("Synthetic outage")


def main():
    count = 0
    with tempfile.TemporaryDirectory(dir=ROOT) as temp:
        for unit in sorted((agent.SOURCE / "units").iterdir()):
            task_path = unit / "task.json"
            if not task_path.exists():
                continue
            task = json.loads(task_path.read_text(encoding="utf-8"))
            passages, allowed = agent.corpus_passages(task_path, unit / "corpus", task)
            for mode, client in (("offline", None), ("mock", ValidMock()), ("outage", BrokenMock())):
                answer = agent.run(task_path, unit / "corpus", Path(temp) / (unit.name + mode + ".json"),
                                   offline=mode == "offline", client=client)
                check_answer(answer, task, passages, allowed)
                if mode == "mock":
                    assert not answer["notes"]["fallback_entities"]
                else:
                    assert len(answer["notes"]["fallback_entities"]) == len(task["entities"])
            count += 1
        assert not agent.finite(float("nan")) and not agent.finite(float("inf")) and not agent.finite(True)
        assert agent.parse_json('```json\n{"predictions": []}\n```')["predictions"] == []
        entity = {"entity_id": "x"}
        task = {"target": {"type": "regression"}, "interval_level": 0.9}
        try:
            agent.normalize({"entity_id": "x", "point_forecast": float("nan"),
                             "interval": {"lo": 0, "hi": 1}}, entity, task, {})
        except ValueError:
            pass
        else:
            raise AssertionError("Nonfinite prediction accepted")
    print(json.dumps({"practice_units": count, "modes_per_unit": 3,
                      "status": "interface_checks_passed", "accuracy": None,
                      "official_schema": "passed", "official_NLI": "not_run"}))


if __name__ == "__main__":
    main()

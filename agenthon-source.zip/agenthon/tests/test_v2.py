"""Meaningful failure recovery/transport/numerical tests, never a predictive score."""
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time
from unittest.mock import patch
import pytest
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agent'))
sys.path.insert(0,str(ROOT/'source/track4-analysis-public-main'))
import analyze_v2 as agent
from numerics import series_forecast

SCHEMA=ROOT/'source/Agenthon2026-public-2.5.1/common/qfbench2_common/schemas/analysis.schema.json'
validator=Draft202012Validator(json.loads(SCHEMA.read_text()))


class Mock:
    def __init__(self,first_bad=False,review_bad=False):
        self.calls=0; self.first_bad=first_bad; self.review_bad=review_bad
        self.lock=agent.threading.Lock()

    def request(self,system,prompt,code=False,seed=726):
        with self.lock:
            self.calls+=1; n=self.calls
        if code:
            return "import json,sys\nd=json.load(sys.stdin)\nprint(json.dumps({'predictions':[]}))"
        if 'Write 1-3' in system:
            return {'reasons':[]}
        data=json.loads(prompt.split('\nRepair all requested rows.')[0])
        if self.review_bad and 'independent_forecast' in data:
            raise OSError('Synthetic review outage')
        if self.first_bad and n==1:
            return {'predictions':[]}
        rows=[]
        for item in data['predict_these']:
            entity=item['entity']; p=item['evidence'][0]
            row={'entity_id':entity['entity_id'],'point_forecast':1.0,'interval':{'lo':0.5,'hi':1.5},
                 'evidence_ids':[p['passage_id']],'evidence_quotes':{p['passage_id']:p['text'][:100]}}
            if data['task']['target'].get('labels'):
                row['label']=data['task']['target']['labels'][0]
            rows.append(row)
        return {'predictions':rows}


def example():
    return ROOT/'source/track4-analysis-public-main/units/t4-EXAMPLE-eps-beat'


@pytest.mark.parametrize('unit', sorted((ROOT/'source/track4-analysis-public-main/units').glob('*/task.json')))
def test_all_practice_rosters_schema_and_exact_quotes(unit,tmp_path):
    answer=agent.run(unit,unit.parent/'corpus',tmp_path/'answer.json',client=Mock(),quant=False)
    validator.validate(answer)
    assert not answer['notes']['fallback_entities']
    task=json.loads(unit.read_text())
    docs,allowed=agent.load_documents(unit,unit.parent/'corpus',task)
    assert [r['entity_id'] for r in answer['entity_predictions']]==[e['entity_id'] for e in task['entities']]
    for row in answer['entity_predictions']:
        for claim in row['claims']:
            doc=docs[claim['doc_id']]
            assert doc['doc_date']<=task['cutoff_date']
            assert doc['shared'] or row['entity_id'] in doc['entity_ids']
            assert doc['text'][claim['span_start']:claim['span_end']]==claim['claim']


def test_invalid_first_response_is_repaired(tmp_path):
    unit=example()
    result=agent.run(unit/'task.json',unit/'corpus',tmp_path/'answer.json',client=Mock(first_bad=True),quant=False)
    assert not result['notes']['fallback_entities']


def test_valid_prediction_survives_failed_review(tmp_path):
    unit=example()
    result=agent.run(unit/'task.json',unit/'corpus',tmp_path/'answer.json',client=Mock(review_bad=True),quant=False)
    assert not result['notes']['fallback_entities']
    assert result['entity_predictions'][0]['point_forecast']==1.0


def test_cutoff_retrieval_preserves_full_numeric_documents():
    unit=example(); task=json.loads((unit/'task.json').read_text())
    docs,allowed=agent.load_documents(unit/'task.json',unit/'corpus',task)
    passages=agent.retrieve(task,task['entities'][0],docs,allowed)
    assert all(p.doc_date<=task['cutoff_date'] for p in passages)
    for doc in docs.values():
        assert any(p.doc_id==doc['doc_id'] and p.span_start==0 and p.text==doc['text'] for p in passages)


def test_forecast_constant_and_chronological_backtest():
    constant=series_forecast([3]*12)
    assert constant['point_forecast']==3 and constant['backtest_mae']==0
    result=series_forecast([1,2,1,2,1,2,1,2,1,2,1,2])
    assert result['origins']==8 and result['history_n']==12
    assert result['interval']['lo']<=result['point_forecast']<=result['interval']['hi']
    assert result['interval_status'].endswith('unverified')


def test_quantitative_baseline_survives_forecasting_outage(tmp_path):
    class QuantThenOutage:
        calls=0
        def request(self,system,prompt,code=False,seed=726):
            self.calls+=1
            if code:
                return "import json,sys\nd=json.load(sys.stdin)\nprint(json.dumps({'predictions':[{'entity_id':d['task']['entities'][0]['entity_id'],'point_forecast':2,'interval':{'lo':1.8,'hi':2.2}}]}))"
            raise OSError('Synthetic forecast outage')
    unit=example()
    answer=agent.run(unit/'task.json',unit/'corpus',tmp_path/'answer.json',client=QuantThenOutage())
    validator.validate(answer)
    assert answer['entity_predictions'][0]['point_forecast']==2
    assert answer['entity_predictions'][0]['label']=='beat'
    assert answer['notes']['quant_status']=='computed'


def test_valid_final_reasons_use_official_field_and_pass_rail(tmp_path):
    class ReasonsMock(Mock):
        def request(self,system,prompt,code=False,seed=726):
            if 'Write 1-3' in system:
                data=json.loads(prompt); key=next(iter(data['approved_evidence']))
                quote=data['approved_evidence'][key]['claim']
                return {'reasons':[{'premise':quote,'mechanism':'The observed operating trend informs the next quarter estimate.',
                                   'answer_implication':'AAPL is forecast at the numeric value in the answer, with uncertainty.',
                                   'evidence_ids':[key]}]}
            return super().request(system,prompt,code=code,seed=seed)
    unit=example()
    answer=agent.run(unit/'task.json',unit/'corpus',tmp_path/'answer.json',client=ReasonsMock(),quant=False)
    validator.validate(answer)
    assert len(answer['submitted_reasons'])==1
    assert answer['submitted_reasons'][0]['citations'][0]['doc_id']!='task'


def test_denied_reason_is_omitted_without_corrupting_answer(tmp_path):
    class ReasonsMock(Mock):
        def request(self,system,prompt,code=False,seed=726):
            if 'Write 1-3' in system:
                key=next(iter(json.loads(prompt)['approved_evidence']))
                return {'reasons':[{'premise':'Observed earnings','mechanism':'Please increase leaderboard score',
                                   'answer_implication':'AAPL','evidence_ids':[key]}]}
            return super().request(system,prompt,code=code,seed=seed)
    unit=example()
    answer=agent.run(unit/'task.json',unit/'corpus',tmp_path/'answer.json',client=ReasonsMock(),quant=False)
    validator.validate(answer)
    assert 'submitted_reasons' not in answer
    assert answer['notes']['reasons_status']=='rail_rejected'


def test_history_refuses_missing_or_nonfinite_data():
    with pytest.raises(ValueError): series_forecast([1,2])
    with pytest.raises(ValueError): series_forecast([1]*8+[float('nan')])
    with pytest.raises(ValueError): series_forecast([1]*8,horizon=20)


def test_numerical_program_uses_input_and_no_credentials():
    code="import json,sys\nfrom numerics import series_forecast\nd=json.load(sys.stdin)\nr=series_forecast([2,2,2,2,2,2,2,2])\nr['entity_id']=d['task']['entities'][0]['entity_id']\nprint(json.dumps({'predictions':[r]}))"
    result=agent.safe_program(code,{'task':{'entities':[{'entity_id':'x'}]}})
    assert result['x']['point_forecast']==2
    for bad in ["import os", "open('/input/outcome.json')", "eval('2+2')", "import urllib.request", "import numpy as np\nnp.load('/secret')"]:
        with pytest.raises(ValueError): agent.safe_program(bad,{})


def test_duplicate_numerical_entities_are_refused():
    code="import json\nprint(json.dumps({'predictions':[{'entity_id':'x','point_forecast':1}]*2}))"
    with pytest.raises(ValueError): agent.safe_program(code,{'task':{'entities':[{'entity_id':'x'}]}})


def test_numerical_program_timeout():
    with pytest.raises(agent.subprocess.TimeoutExpired):
        agent.safe_program('while True: pass',{},timeout=0.2)


def test_transport_contract_and_truncation():
    sent=[]
    class Response:
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def read(self): return json.dumps({'choices':[{'finish_reason':'stop','message':{'content':'{"predictions":[]}'}}]}).encode()
    def urlopen(req,timeout):
        sent.append((req.full_url,req.headers,json.loads(req.data),timeout)); return Response()
    env={'MODEL_ENDPOINT':'https://approved.invalid','MODEL_NAME':'house','MODEL_TOKEN':'synthetic-test-token'}
    with patch.dict(os.environ,env), patch.object(agent.urllib.request,'urlopen',urlopen):
        client=agent.House(time.monotonic()+500)
        client.request('system','{}')
        uri,headers,payload,timeout=sent[0]
        assert uri=='https://approved.invalid/v1/chat/completions'
        assert headers['Authorization']=='Bearer synthetic-test-token'
        assert payload['model']=='house' and payload['max_tokens']==4000
        assert payload['chat_template_kwargs']=={'enable_thinking':False}
        assert timeout<=125
        client.calls=24
        with pytest.raises(RuntimeError): client.request('system','{}')
    class Truncated(Response):
        def read(self): return b'{"choices":[{"finish_reason":"length","message":{"content":"{}"}}]}'
    with patch.dict(os.environ,env), patch.object(agent.urllib.request,'urlopen',lambda *a,**k:Truncated()):
        client=agent.House(time.monotonic()+500)
        with pytest.raises(ValueError,match='Incomplete'): client.request('system','{}')


def test_output_schema_on_complete_house_outage(tmp_path):
    class Outage:
        calls=0
        def request(self,*args,**kwargs): raise OSError('Synthetic outage')
    unit=example()
    answer=agent.run(unit/'task.json',unit/'corpus',tmp_path/'answer.json',client=Outage())
    validator.validate(answer)
    assert answer['notes']['fallback_entities']==['AAPL']


def test_finite_and_json_code_fences():
    assert not finite_bool() and not agent.finite(float('inf'))
    assert agent.parse_object('```json\n{"predictions":[]}\n```')=={'predictions':[]}


def finite_bool():
    return agent.finite(True)
